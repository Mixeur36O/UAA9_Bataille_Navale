﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5T25_Limet_BatailleNaval
{
    public struct mesOutils
    {
        /// <summary>
        /// On remplis la grille avec * qui représente l'eau
        /// </summary>
        /// <param name="grille">Le plateau de jeu</param>
        public void iniGrille(char[,] grille)
        {
            const char eau = '*'; // symbole de l'eau
            for (int iColonne = 0; iColonne < 10; iColonne++)
            {
                for (int iLigne = 0; iLigne < 10; iLigne++)
                {
                    grille[iLigne, iColonne] = eau;
                }
            }
        }
        /// <summary>
        /// Fonction pour afficher la grille
        /// </summary>
        /// <param name="grille">Le plateau de jeu</param>
        public void AfficherGrille(char[,] grille)
        {
            Console.Write("  ");
            for (int iLigne = 0; iLigne < 10; iLigne++)
            {
                Console.Write($"{iLigne} ");
            }
            Console.WriteLine();

            for (int iColonne = 0; iColonne < 10; iColonne++)
            {
                Console.Write($"{iColonne} ");
                for (int iLigne = 0; iLigne < 10; iLigne++)
                {
                    Console.Write($"{grille[iLigne, iColonne]} ");
                }
                Console.WriteLine();
            }
        }
        /// <summary>
        /// Fonction pour placer les bateaux
        /// </summary>
        /// <param name="grille">Le plateau de jeu</param>
        public void placeBateaux(char[,] grille)
        {
            const char bateau = 'B'; // symbole des bateux
            const int cuirasse = 5;
            const int contreTorpilleur = 4;
            const int sousMarin = 3;
            const int bateuSauvetage = 2;
            int iLigne = 0;
            int i = 0;
            int iColonne = 0;
            string choix = "";
            string horyzontal = "oui";
            for (int continuer = 0; continuer < 4; continuer++)
            {
                Console.WriteLine("Choisissez un bateau à placer (cuirassé = 5, contre-torpilleur = 4, sous-marin = 3, bateau de sauvetage = 2)");
                choix = Console.ReadLine();
                if (choix == "cuirassé")
                {
                    Console.WriteLine("voulez-vous mettre votre bateaux à l'horyzontal ?");
                    horyzontal = Console.ReadLine();
                    Console.WriteLine("Donné moi une ligne");
                    int iLigneU = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Donné moi une colonne");
                    int iColonneU = Convert.ToInt32(Console.ReadLine());
                    int[,] coordonnées = new int[iLigneU,iColonneU];
                    if (horyzontal == "oui")
                    {
                        if (cuirasse + i < grille.GetLength(0))
                        {
                            coordonnées[iLigneU, iColonneU] = bateau;
                            grille[cuirasse + i, iColonne] = Convert.ToChar(coordonnées[iLigneU, iColonneU]);
                        }
                        else
                        {
                            Console.WriteLine("Ceci n'est pas possible");
                        }
                    }
                    else
                    {

                    if (cuirasse + i < grille.GetLength(1))
                    {
                        grille[iLigne, cuirasse + i] = bateau;
                    }
                    else
                    {
                        Console.WriteLine("Ceci n'est pas possible");
                    }

                    }
                }
            }
        }
    }
}
